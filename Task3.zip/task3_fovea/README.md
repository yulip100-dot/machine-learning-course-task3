# 中心凹检测定位课程设计

本仓库整理已完成的 Kaggle Task 3 实验。最终候选为冻结 ImageNet ResNet-18、多尺度热力图、权重 0.25 的几何先验和水平翻转等权推理。该版本使用五折、单个初始化种子的模型。代码不训练可见性分类器；80个训练样本全部可见，不能声称支持不可见中心凹的可靠判定。

## 文件与运行顺序

- `train.py`：从数据检查、分组、基线、热力图训练，到先验拟合、权重扫描、翻转消融和提交导出，按最终原始笔记本顺序运行；最后保存编码器，并在独立进程检查推理一致性。
- `predict.py`：只读取测试图像、提交模板及保存的模型，不需要训练标注。固定使用五折热力图头、λ=0.25、原图与水平翻转等权融合。
- `src/submission.py`：严格按模板解析图片编号与X/Y，检查重复项、遗漏、非有限值及像素边界。
- `tests/test_submission.py`：提交顺序、边界、坐标翻转与裁剪往返检查。
- `notebooks/task3_optimistic2_original.ipynb`：最终实验，运行版本362843398。保留全部代码与文本输出，移除较大的内嵌PNG，便于GitHub阅读。`train.py`直接读取这个文件，不能单独删除。
- `notebooks/task3_notebook_original.ipynb`：冻结ResNet-18与λ=1的前期实验，版本362465390，包含双种子、替代划分及独立推理记录。
- `notebooks/task3_2_original.ipynb`：早期TinyUNet局部精修，版本361788293。它依赖已删除上游Kernel中的粗定位结果，只作为历史证据，不能单独从零复现；最终流程不依赖它。
- `docs/RESULTS.md`：报告数字来源、可比性和复现边界。

## 数据准备

从比赛页面获取数据，按原结构保留。仓库不重新分发比赛图像或标注。

```text
data/detection/
  train/0001.jpg ... 0080.jpg
  test/0081.jpg ... 0100.jpg
  train_location/0001.xml ... 0080.xml
  fovea_localization_train_GT.csv
  sample_submission.csv
```

训练标注列为`data,Fovea_X,Fovea_Y`。提交列为`ImageID,value`，例如`81_Fovea_X`后接`81_Fovea_Y`。不可把训练表的三列直接上传。脚本会检查实际尺寸、像素重复、坐标范围及标注框关系；训练时必须给数据目录，而不是整个含有其他数据集的Kaggle input目录。

## 环境

原始运行使用Tesla T4、PyTorch 2.11.0+cu128和Torchvision 0.26.0+cu128。训练入口要求CUDA；独立推理可在CPU运行。建议在Kaggle GPU环境运行。需要足够显存容纳原图和翻转图的100张448×64×64浮点特征，以及训练中间结果。

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

PyTorch与Torchvision须使用匹配的CUDA构建。若平台已提供匹配版本，不必覆盖安装。其余依赖版本范围用于安装，原笔记本未输出它们的精确版本；不同版本可能导致数值或分折差异，不能承诺逐位重现。

第一次训练需要下载官方`ResNet18_Weights.IMAGENET1K_V1`（resnet18-f37072fd.pth）。离线训练须事先将该权重放入PyTorch缓存，并安装全部依赖。`predict.py`只加载训练后保存的encoder.pt，不联网下载权重。数据和模型不在本代码包内。

## 完整训练与评估

```bash
python train.py --data data/detection --output runs/final_tta
```

Kaggle中可将仓库上传为代码Dataset，在笔记本运行：

```python
import subprocess, sys
subprocess.run([
    sys.executable, '/kaggle/input/YOUR_CODE_DATASET/task3_fovea/train.py',
    '--data', '/kaggle/input/competitions/2026task3/detection',
    '--output', '/kaggle/working/final_tta_run'
], check=True)
```

将`YOUR_CODE_DATASET`替换成实际挂载名。输出目录必须不存在或为空，防止旧检查点改变模型选择。原笔记本会检查是否存在alternate模型；整理后的入口固定采用已记录的original_seed_20261025模型组。这里只改变路径、明确模型组、添加编码器保存及独立推理核验，不改变已记录的训练损失、训练轮数或最终融合权重。

入口依次执行原笔记本的全部代码单元，包含不进入最终模型的岭回归基线及λ扫描。它不是只运行最后几个单元。训练完成后主要输出：

```text
runs/final_tta/
  fovea_experiment_v1/folds.csv
  fovea_experiment_v2/
    encoder.pt
    heatmap_fold0.pt ... heatmap_fold4.pt
    geometry_prior_fold0.joblib ... geometry_prior_fold4.joblib
    heatmap_training_history.csv
    geometry_lambda_sweep.csv
    tta_results_original_seed_20261025.csv
    tta_oof_predictions_original_seed_20261025.csv
  submission_tta_lambda_0p25.csv
  submission_tta_lambda_0p25.zip
  submission_independent.csv
  inference_replay_check.json
  run_environment.json
```

五折头文件还包含各折训练特征均值、标准差和训练轮数。先验文件包含岭回归模型及折内估计的二维宽度。最终模型应整体保留编码器、五个头文件和五个先验文件；不能只复制一个head权重。

## 独立推理

```bash
python predict.py --data data/detection --model runs/final_tta/fovea_experiment_v2 --output runs/submission.csv
```

该命令仅使用`data/detection/test/`与`sample_submission.csv`。输出40行，保持模板顺序，每图X/Y相邻。不会自动向Kaggle提交。模型采用Softmax期望坐标，没有受监督的“不可见”分支，也没有为某些测试图像手工指定坐标。

## 已完成检查与未完成检查

整理时已检查所有Python文件及最终笔记本代码单元的语法，并运行四项CPU数值/格式测试。未在本次整理环境重新执行GPU训练：这里没有比赛原始数据、PyTorch或CUDA。历史实验成绩来自原始已执行笔记本，不是本地新跑出的结果。新增训练入口及最终TTA独立推理入口尚需在有数据的GPU环境端到端运行；训练入口内置两种导出结果最大差异小于0.01像素的检查。通过后才会输出`TRAINING AND INDEPENDENT INFERENCE COMPLETED`。

## GitHub上传

在GitHub创建空仓库后，将解压出的`task3_fovea`目录内容上传，保留上述子目录。命令行方式如下，URL替换成自己的仓库：

```bash
git init
git add README.md requirements.txt .gitignore train.py predict.py src tests notebooks docs
git commit -m "Add fovea localization experiments and reproducible workflow"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

不要提交比赛数据、模型大文件或Kaggle凭证。`.gitignore`已排除常见相关文件。没有代为创建仓库或执行推送；用户可检查后自行上传。
