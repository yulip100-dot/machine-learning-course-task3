
from pathlib import Path
import argparse
from src.submission import build_submission
import numpy as np
import pandas as pd
from PIL import Image
import cv2, torch, joblib
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import resnet18
parser=argparse.ArgumentParser()
parser.add_argument('--data',required=True)
parser.add_argument('--model',required=True)
parser.add_argument('--output',required=True)
args=parser.parse_args()
base=Path(args.data); modeldir=Path(args.model)
sample=pd.read_csv(base/'sample_submission.csv')
assert list(sample.columns)==['ImageID','value'] and sample.ImageID.is_unique
parts=sample.ImageID.str.extract(r'^(\d+)_Fovea_([XY])$')
assert not parts.isna().any().any()
ids=sorted(parts[0].astype(int).unique())
paths={int(p.stem):p for p in (base/'test').glob('*.jpg')}
assert set(ids)==set(paths), 'Sample/test image mismatch'
device=torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
torch.set_num_threads(2)
enc=resnet18(weights=None).to(device).eval()
enc.load_state_dict(torch.load(modeldir/'encoder.pt',map_location=device,weights_only=True))
mean=torch.tensor([.485,.456,.406],device=device)[None,:,None,None]
std=torch.tensor([.229,.224,.225],device=device)[None,:,None,None]
coord=(torch.arange(64,device=device)+.5)/64
gy,gx=torch.meshgrid(coord,coord,indexing='ij')
grid=torch.stack([gx,gy])[None]
class HeatmapHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.net=nn.Sequential(nn.Conv2d(450,64,1),nn.GELU(),nn.Dropout2d(.1),nn.Conv2d(64,32,3,padding=1),nn.GELU(),nn.Conv2d(32,1,1))
    def forward(self,z):
        return self.net(torch.cat([z,grid.expand(len(z),-1,-1,-1)],1)).flatten(1)
def decode(logits):
    p=logits.softmax(1)
    return torch.stack([(p*gx.flatten()).sum(1),(p*gy.flatten()).sum(1)],1)
wh=[]; offsets=[]; sizes=[]; discs=[]; ims=[]
for i in ids:
    with Image.open(paths[i]) as im:
        a=np.asarray(im.convert('RGB')).copy()
        w,h=im.size
        ims.append(np.asarray(im.convert('RGB').resize((512,512),Image.Resampling.BILINEAR)).copy())
    small=cv2.resize(a,(512,512),interpolation=cv2.INTER_AREA)
    mask=((small[:,:,1]>8)&(small.sum(2)>30)).astype(np.uint8)
    n,labels,stats,cent=cv2.connectedComponentsWithStats(mask,8)
    assert n>1
    cc=stats[1:,cv2.CC_STAT_AREA].argmax()+1
    x0,y0,cw,ch,area=stats[cc]
    assert area>512*512*.1
    left=max(0,int(x0/512*w)-int(.01*w));top=max(0,int(y0/512*h)-int(.01*h))
    right=min(w,int(np.ceil((x0+cw)/512*w))+int(.01*w))
    bottom=min(h,int(np.ceil((y0+ch)/512*h))+int(.01*h))
    crop=cv2.resize(a[top:bottom,left:right],(512,512),interpolation=cv2.INTER_AREA)
    g=cv2.GaussianBlur(crop[:,:,1].astype(np.float32),(0,0),8)
    mask=np.zeros((512,512),bool);mask[128:384,41:471]=True;g[~mask]=-1
    yy0,xx0=np.unravel_index(g.argmax(),g.shape)
    discs.append([xx0/512,yy0/512]);wh.append([w,h]);offsets.append([left,top]);sizes.append([right-left,bottom-top])
wh=np.array(wh);offsets=np.array(offsets);sizes=np.array(sizes);discs=np.array(discs)
geomX=np.column_stack([discs[:,0],discs[:,1],np.where(discs[:,0]<.5,1.,-1.)])
features=[]
flip_features=[]
with torch.inference_mode():
    for flipped, destination in [(False, features), (True, flip_features)]:
        for start in range(0,len(ids),4):
            arr=np.stack(ims[start:start+4])
            if flipped: arr=np.flip(arr,axis=2).copy()
            z=torch.tensor(arr,device=device).permute(0,3,1,2).float()/255
            z=enc.maxpool(enc.relu(enc.bn1(enc.conv1((z-mean)/std))))
            l1=enc.layer1(z);l2=enc.layer2(l1);l3=enc.layer3(l2)
            destination.append(torch.cat([F.adaptive_avg_pool2d(l1,64),l2,F.interpolate(l3,size=(64,64),mode='bilinear',align_corners=False)],1))
    features=torch.cat(features)
    flip_features=torch.cat(flip_features)
    preds=[]
    for flipped in [False, True]:
        prefix='heatmap'
        current_features=flip_features if flipped else features
        for f in range(5):
            state=torch.load(modeldir/f'{prefix}_fold{f}.pt',map_location=device,weights_only=False)
            head=HeatmapHead().to(device).eval();head.load_state_dict(state['head'])
            gp=joblib.load(modeldir/f'geometry_prior_fold{f}.joblib')
            pn=(gp['model'].predict(geomX)*sizes+offsets)/wh
            ps=gp['spread'][None]*sizes/wh
            if flipped: pn[:,0]=(wh[:,0]-1)/wh[:,0]-pn[:,0]
            chunks=[]
            for start in range(0,len(ids),5):
                sl=slice(start,start+5)
                logits=head(((current_features[sl]-state['mean'].to(device))/state['std'].to(device)).clamp(-8,8))
                pc=torch.tensor(pn[sl],device=device,dtype=torch.float32)
                sc=torch.tensor(ps[sl],device=device,dtype=torch.float32)
                lp=-.5*(((gx[None]-pc[:,0,None,None])/sc[:,0,None,None])**2+((gy[None]-pc[:,1,None,None])/sc[:,1,None,None])**2)
                pp=decode(logits+0.25*lp.flatten(1)).cpu().numpy()
                if flipped: pp[:,0]=(wh[sl,0]-1)/wh[sl,0]-pp[:,0]
                chunks.append(pp)
            preds.append(np.concatenate(chunks)*wh)
            del head
pred=np.mean(preds,axis=0)
assert np.isfinite(pred).all() and (pred>=0).all() and (pred<wh).all()
mapping={i:p for i,p in zip(ids,pred)}
result=build_submission(sample,mapping,{i: s for i,s in zip(ids,wh)})
assert list(result.columns)==['ImageID','value'] and result.ImageID.equals(sample.ImageID)
assert len(result)==2*len(ids)
Path(args.output).parent.mkdir(parents=True,exist_ok=True)
result.to_csv(args.output,index=False)
back=pd.read_csv(args.output)
assert back.ImageID.equals(sample.ImageID) and np.isfinite(back.value).all()
print('INFERENCE PASSED',len(ids),'images',len(back),'rows; no train labels read.')
print(back.head(6).to_string(index=False))
