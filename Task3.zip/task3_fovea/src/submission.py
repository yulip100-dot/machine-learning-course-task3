"""Strict sample-order mapping; no sorting or implicit fallback axis."""
import re
import numpy as np
import pandas as pd


def build_submission(sample, predictions, sizes):
    if list(sample.columns) != ['ImageID', 'value'] or not sample.ImageID.is_unique:
        raise ValueError('Invalid sample schema or duplicate ID')
    values, seen = [], set()
    for text in sample.ImageID:
        match = re.fullmatch(r'(\d+)_Fovea_([XY])', str(text))
        if not match:
            raise ValueError(f'Invalid ImageID: {text}')
        i, axis = int(match[1]), 0 if match[2] == 'X' else 1
        value = float(predictions[i][axis])
        if not np.isfinite(value) or not 0 <= value < sizes[i][axis]:
            raise ValueError(f'Invalid coordinate: {text}')
        seen.add((i, axis)); values.append(value)
    if seen != {(i, a) for i in predictions for a in [0, 1]}:
        raise ValueError('Missing or extra image/axis')
    result = sample.copy()
    result['value'] = values
    return result
