import unittest
import numpy as np
import pandas as pd
from src.submission import build_submission


class SubmissionTest(unittest.TestCase):
    def test_order_and_axes(self):
        sample = pd.DataFrame({'ImageID': ['82_Fovea_X', '82_Fovea_Y', '81_Fovea_X', '81_Fovea_Y'], 'value': [None]*4})
        result = build_submission(sample, {81: [3., 4.], 82: [5., 6.]}, {81: [10, 10], 82: [10, 10]})
        self.assertEqual(result.value.tolist(), [5., 6., 3., 4.])
        self.assertEqual(result.ImageID.tolist(), sample.ImageID.tolist())

    def test_invalid_coordinate(self):
        sample = pd.DataFrame({'ImageID': ['81_Fovea_X','81_Fovea_Y'], 'value': [None]*2})
        for coord in [[np.nan, 1], [10, 1], [-1, 1]]:
            with self.assertRaises(ValueError):
                build_submission(sample, {81: coord}, {81: [10, 10]})

    def test_flip_roundtrip(self):
        w = 2992
        x = np.array([0., 734.031331, w-1.])
        np.testing.assert_allclose((w-1)-((w-1)-x), x, atol=1e-10)

    def test_crop_roundtrip(self):
        xy = np.array([[1000.25, 1100.5]])
        off, size = np.array([[400., 10.]]), np.array([[2000., 1980.]])
        np.testing.assert_allclose((xy-off)/size*size+off, xy, atol=1e-10)


if __name__ == '__main__':
    unittest.main()
