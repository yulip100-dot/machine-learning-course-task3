"""Replay the verified final Kaggle experiment in a fresh output directory.

Code cells remain in the archived notebook for a direct audit trail. This
launcher changes paths and removes the implicit choice of stale alternate
models. It also saves the encoder and verifies standalone inference.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', required=True, help='directory containing train, test, and both CSVs')
    parser.add_argument('--output', required=True, help='new or empty output directory')
    args = parser.parse_args()
    data, output = Path(args.data).resolve(), Path(args.output).resolve()
    for item in ['train', 'test', 'train_location', 'fovea_localization_train_GT.csv', 'sample_submission.csv']:
        if not (data / item).exists():
            raise FileNotFoundError(data / item)
    if output.exists() and any(output.iterdir()):
        raise RuntimeError('Use a new/empty output directory; stale checkpoints could change the experiment.')
    output.mkdir(parents=True, exist_ok=True)
    os.environ['MPLBACKEND'] = 'Agg'
    repo = Path(__file__).resolve().parent
    notebook = json.loads((repo / 'notebooks/task3_optimistic2_original.ipynb').read_text())
    namespace = {'__name__': '__experiment__'}
    replacements = {
        "Path('/kaggle/input')": f'Path({str(data)!r})',
        "Path('/kaggle/input/competitions/2026task3/detection')": f'Path({str(data)!r})',
        '/kaggle/working': str(output),
    }
    for i, cell in enumerate(notebook['cells']):
        if cell['cell_type'] != 'code':
            continue
        source = ''.join(cell['source'])
        for old, new in replacements.items():
            source = source.replace(old, new)
        if i == 15:
            source = source.replace('use_alt = all(p.exists() for p in alt_head_files + alt_geo_files) and alt_fold_file.exists()', 'use_alt = False  # Explicitly reproduce the recorded final run')
        print(f'Executing original notebook cell {i}', flush=True)
        exec(compile(source, f'notebook_cell_{i}', 'exec'), namespace)
    import torch
    import pandas as pd
    import numpy as np
    model = output / 'fovea_experiment_v2'
    torch.save({k: v.cpu() for k, v in namespace['backbone'].state_dict().items()}, model / 'encoder.pt')
    (output / 'run_environment.json').write_text(json.dumps({
        'python': sys.version, 'torch': torch.__version__,
        'torchvision': namespace['torchvision'].__version__,
        'numpy': np.__version__, 'pandas': pd.__version__,
        'model': 'frozen_resnet18_heatmap_lambda0.25_horizontal_tta',
        'source_version': 362843398,
        'invisible_case_supported': False,
    }, indent=2))
    target = output / 'submission_independent.csv'
    subprocess.run([sys.executable, str(repo / 'predict.py'), '--data', str(data),
                    '--model', str(model), '--output', str(target)], check=True)
    original = pd.read_csv(output / 'submission_tta_lambda_0p25.csv')
    independent = pd.read_csv(target)
    assert original.ImageID.equals(independent.ImageID)
    delta = float(np.abs(original.value - independent.value).max())
    assert delta < .01, f'Inference replay mismatch: {delta} pixels'
    (output / 'inference_replay_check.json').write_text(json.dumps({'max_abs_difference_pixels': delta, 'passed': True}, indent=2))
    print('TRAINING AND INDEPENDENT INFERENCE COMPLETED', flush=True)


if __name__ == '__main__':
    main()
